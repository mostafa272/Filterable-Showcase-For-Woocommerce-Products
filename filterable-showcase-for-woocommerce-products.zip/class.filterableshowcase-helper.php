<?php
class fsfwp_filterableshowcase_helper{
static function fsfwp_filterable_showcase_get_article($allcats,$allauthors,$alltags,$params)
{
$output=array();
//removing zero value from  categories,authors,tags IDs array
 if (($key1 = array_search("0", $allcats)) !== false) {
    unset($allcats[$key1]);
    $allcats=array_values($allcats);
   }
  if (($key2 = array_search("0", $allauthors)) !== false) {
    unset($allauthors[$key2]);
    $allauthors=array_values($allauthors);
   }
   if (($key3 = array_search("0", $alltags)) !== false) {
    unset($alltags[$key3]);
    $alltags=array_values($alltags);
   }
   //getting posts or pages based on filters
   $metakey='';
   if($params['orderby']=='review')
   {
    $orderby='meta_value_num';
    $metakey='_wc_review_count';
   }
   else if($params['orderby']=='rating')
   {
    $orderby='meta_value_num';
    $metakey='_wc_review_count';
   }
   else if($params['orderby']=='totalsale')
   {
    $orderby='meta_value_num';
    $metakey='total_sales';
   }
  else if($params['orderby']=='price')
   {
    $orderby='meta_value_num';
    $metakey='_price';
   }
   else{
   $orderby=$params['orderby'];
   $metakey='';
   }
   $data = get_userdata( get_current_user_id() );
    $current_user_caps = $data->allcaps;
    $post_status=($current_user_caps['read_private_posts']==1)?array('publish','private'):array('publish');
 if($params['count']!=0 && (!empty($allcats) || !empty($allauthors) || !empty($alltags)))
 { $output=get_posts(array('posts_per_page'=>$params['count'],'offset'=>$params['offset'],'tax_query'=>array('relation'=>'AND',array('taxonomy'=>'product_cat','field'=>'term_id','terms'=>$allcats,'operator'=>$allcats?'IN':'NOT IN'),array('taxonomy'=>'product_tag','field'=>'term_id','terms'=>$alltags,'operator'=>$alltags?'IN':'NOT IN')),'author__in'=>$allauthors,'orderby'=>$orderby,'order'=>$params['sort'],'meta_key'=>$metakey,'post_type'=>'product' ,'post_status'=>$post_status));
 }

  if(!empty($output))
  {  //adding extra attributes
    foreach($output as $p)
   { $product=wc_get_product($p->ID);
     $p->image = has_post_thumbnail($p->ID)? '<div class="fsfwp_img">'.get_the_post_thumbnail($p->ID).'</div>':'';
      $content = get_extended($p->post_content);
      $p->intro =($params['introsource']==1)? $p->post_excerpt :$content['main'];
      $p->link = get_permalink($p->ID);
      $p->activeprice= $product->get_price();
      $p->formerprice= $product->is_on_sale()?$product->get_regular_price():'';
      $p->onsale=$product->is_on_sale();
      $p->review=$product->get_review_count();
      $p->sales=$product->get_total_sales();
      $p->rating=$product->get_average_rating();
      $p->ratingcount=$product->get_rating_count();
      $p->cart= $product->is_in_stock()?$product->add_to_cart_url():'';
      $p->author_name = get_the_author_meta('display_name',$p->post_author);
 //adding categories links for posts
      $cats=get_the_terms( $p->ID, 'product_cat' );
      foreach($cats as $c)
      $p->catlink=(empty($p->catlink))?'<a class="fsfwp_cats" href="'.esc_url(get_term_link($c->term_id,'product_cat')).'">'.$c->name.'</a>':$p->catlink.', <a class="fsfwp_cats" href="'.esc_url(get_term_link($c->term_id,'product_cat')).'">'.$c->name.'</a>';

      if($params['type']=='bytags')
      {
        $tags=get_the_terms($p->ID,'product_tag');
        foreach($tags as $t)
        $p->classname=(empty($p->classname))?'fsfwpcolumn fsclass'.$t->term_id:$p->classname.' fsclass'.$t->term_id;
      }
      else if($params['type']=='bycats')
      { foreach($cats as $c)
        $p->classname=(empty($p->classname))?'fsfwpcolumn fsclass'.$c->term_id:$p->classname.' fsclass'.$c->term_id;
      }
      else if($params['type']=='byauthors')
      { $p->classname=(empty($p->classname))?'fsfwpcolumn fsclass'.$p->post_author:$p->classname.' fsclass'.$p->post_author;
      }

   }
   }
 return $output;
}
}