<?php
/*
Plugin Name: Filterable Showcase for Woocommerce Products
Plugin URI: https://github.com/mostafa272/Filterable-Showcase-For-Woocommerce-Products
Description: Filterable Showcase for Woocommerce Products is a simple widget to show woocommerce products based on different filters
Version: 1.0
Text Domain: filterable-showcase-for-woocommerce-products
WC requires at least: 3.0.0
WC tested up to: 3.3
Author: Mostafa Shahiri<mostafa2134@gmail.com>
Author URI: https://github.com/mostafa272/
*/
/*  Copyright 2009  Mostafa Shahiri(email : mostafa2134@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
//prevent direct access and checking woocommerce
if ( !defined('ABSPATH')) exit;
//register widget
add_action("widgets_init", function () { register_widget("Fsfwp_FilterableShowcase"); });

class Fsfwp_FilterableShowcase extends WP_Widget
{
    public function __construct() {
        parent::__construct("fsfwp_filterableshowcase", "Filterable Showcase for WC Products",
            array("description" => "A simple widget to show woocommerce products based on different filters"));
            add_action( 'wp_enqueue_scripts',array($this,'fsfwp_filterable_showcase_scripts') );
            add_action( 'wp_ajax_fsfwproducts',array($this, 'fsfwproducts_ajax_callback') );
            add_action( 'wp_ajax_nopriv_fsfwproducts',array($this, 'fsfwproducts_ajax_callback')  );
            require_once( plugin_dir_path( __FILE__ ) . 'class.filterableshowcase-helper.php');
    }
    public function form($instance) {

    //initial values

        $title=$instance["title"];
        $type=$instance["type"];
        $alltags=(!empty($instance["alltags"]))?$instance["alltags"]:array("0");
        $allcats=(!empty($instance["allcats"]))?$instance["allcats"]:array("0");
        $allauthors=(!empty($instance["allauthors"]))?$instance["allauthors"]:array("0");
        $introsource=$instance["introsource"];
        $count=$instance["count"];
        $limit=$instance["limit"];
        $orderby=$instance["orderby"];
        $sort=$instance["sort"];
        $showcats=$instance["showcats"];
        $showauthor=$instance["showauthor"];
        $showrating=$instance["showrating"];
        $showsalenum=$instance["salenum"];
        $showreview=$instance["review"];
        $showactiveprice=$instance["activeprice"];
        $showformerprice=$instance["formerprice"];
        $showdesc=$instance["showdesc"];
        $showmorebtn=$instance["showmorebtn"];
        $showcartbtn=$instance["showcartbtn"];
        $readmore=(!empty($instance["readmore"]))?$instance["readmore"]:'Read More ...';
        $addcart=(!empty($instance["addcart"]))?$instance["addcart"]:'Add to cart ...';

    //title field for widget
    $titleId = $this->get_field_id("title");
    $titleName = $this->get_field_name("title");
    echo '<p><label for="'.$titleId.'">Title:</label><br>';
    echo '<input id="'.$titleId.'" type="text" name="'.$titleName.'" value="'.$title.'"></p>';
     //select source type
    $typeId = $this->get_field_id("type");
    $typeName = $this->get_field_name("type");
    echo '<label for="'.$typeId.'">Source Type:</label><br>';
    echo '<select id="'.$typeId.'" name="'.$typeName.'">';
    echo '<option value="1" '.selected( '1', $type ).'>Tags</option>';
    echo '<option value="2" '.selected( '2', $type ).'>Categories</option>';
    echo '<option value="3" '.selected( '3', $type ).'>Authors</option>';
    echo '</select>';
   //get tags
    $alltagsId = $this->get_field_id("alltags");
    $alltagsName = $this->get_field_name("alltags");
   $tags = get_terms('product_tag');
   echo '<p><label for="'.$alltagsId.'">Tags:</label><br>';
  echo '<select id="'.$alltagsId.'" name="'.$alltagsName.'[]" multiple="true">';
  echo '<option value="0" '.selected('true',in_array('0' , $alltags)?'true':'false' ).'>-- Select Tags --</option>';
   foreach ($tags as $tag){
   echo '<option value="'.$tag->term_id.'" '.selected( 'true' , in_array($tag->term_id,$alltags)?'true':'false' ).'>'.$tag->name.'</option>';
   }
   echo '</select></p>';

  //get categories
    $allcatsId = $this->get_field_id("allcats");
    $allcatsName = $this->get_field_name("allcats");
    $arg2=array('taxonomy'=>'product_cat');
   $cats = get_categories($arg2);
   echo '<p><label for="'.$allcatsId.'">Categories:</label><br>';
  echo '<select id="'.$allcatsId.'" name="'.$allcatsName.'[]" multiple="true">';
  echo '<option value="0" '.selected('true',in_array('0' , $allcats)?'true':'false' ).'>-- Select Categories --</option>';
   foreach ($cats as $cat){
   echo '<option value="'.$cat->term_id.'" '.selected( 'true' , in_array($cat->term_id,$allcats)?'true':'false' ).'>'.$cat->cat_name.'</option>';
   }
   echo '</select></p>';

   //get authors
     $allauthorsId = $this->get_field_id("allauthors");
    $allauthorsName = $this->get_field_name("allauthors");
   $authors = get_users();
   echo '<p><label for="'.$allauthorsId.'">Authors:</label><br>';
  echo '<select id="'.$allauthorsId.'" name="'.$allauthorsName.'[]" multiple="true">';
  echo '<option value="0" '.selected('true',in_array('0' , $allauthors)?'true':'false' ).'>-- Select Authors --</option>';
   foreach ($authors as $author){
   echo '<option value="'.$author->ID.'" '.selected( 'true' , in_array($author->ID,$allauthors)?'true':'false' ).'>'.$author->display_name.'['.$author->user_login.']</option>';
   }
   echo '</select></p>';
   //intro text type
   $introsourceId = $this->get_field_id("introsource");
    $introsourceName = $this->get_field_name("introsource");
    echo '<label for="'.$introsourceId.'">Intro Text Source Type:</label><br>';
    echo '<select id="'.$introsourceId.'" name="'.$introsourceName.'">';
    echo '<option value="1" '.selected( '1', $introsource ).'>Short Description</option>';
    echo '<option value="2" '.selected( '2', $introsource ).'>Main Description</option>';
    echo '</select>';
   //number of posts to fetch from categories
    $countId = $this->get_field_id("count");
    $countName = $this->get_field_name("count");
    echo '<p><label for="'.$countId.'">Count:</label><br>';
    echo '<input id="'.$countId.'" type="number" name="'.$countName.'" value="'.$count.'"></p>';
    //limit description length
    $limitId = $this->get_field_id("limit");
    $limitName = $this->get_field_name("limit");
    echo '<p><label for="'.$limitId.'">Limit Description Length:</label><br>';
    echo '<input id="'.$limitId.'" type="number" name="'.$limitName.'" value="'.$limit.'"></p>';
    //orderby box
    $orderbyId = $this->get_field_id("orderby");
    $orderbyName = $this->get_field_name("orderby");
    echo '<p><label for="'.$orderbyId.'">Order By:</label><br>';
    echo '<select id="'.$orderbyId.'" name="'.$orderbyName.'">';
    echo '<option value="date" '.selected( 'date', $orderby ).'>Created Date</option>';
    echo '<option value="modified" '.selected( 'modified', $orderby ).'>Modified Date</option>';
    echo '<option value="rand" '.selected( 'rand', $orderby ).'>Random</option>';
    echo '<option value="review" '.selected( 'review', $orderby ).'>Reviews Count</option>';
    echo '<option value="rating" '.selected( 'rating', $orderby ).'>Rating</option>';
    echo '<option value="totalsale" '.selected( 'totalsale', $orderby ).'>Total Sales</option>';
    echo '<option value="price" '.selected( 'price', $orderby ).'>Price</option>';
    echo '</select></p>';
    //order type
    $sortId = $this->get_field_id("sort");
    $sortName = $this->get_field_name("sort");
    echo '<p><label for="'.$sortId.'">Order:</label><br>';
    echo '<select id="'.$sortId.'" name="'.$sortName.'">';
    echo '<option value="DESC" '.selected( 'DESC', $sort ).'>Descending</option>';
    echo '<option value="ASC" '.selected( 'ASC', $sort ).'>Ascending</option>';
    echo '</select></p>';

    //text for readmore link
    $readmoreId = $this->get_field_id("readmore");
    $readmoreName = $this->get_field_name("readmore");
    echo '<p><label for="'.$readmoreId.'">Read More Text:</label><br>';
    echo '<input id="'.$readmoreId.'" type="text" name="'.$readmoreName.'" value="'.$readmore.'"></p>';
    //text for readmore link
    $addcartId = $this->get_field_id("addcart");
    $addcartName = $this->get_field_name("addcart");
    echo '<p><label for="'.$addcartId.'">Add to cart Text:</label><br>';
    echo '<input id="'.$addcartId.'" type="text" name="'.$addcartName.'" value="'.$addcart.'"></p>';
    //an option for showing categories names of the posts
    $showcatsId = $this->get_field_id("showcats");
    $showcatsName = $this->get_field_name("showcats");
    ?><p><input id="<?php echo $showcatsId;?>" type="checkbox" name="<?php echo $showcatsName;?>" value="1" <?php checked( 1, $showcats );?>>Show Categories</p>
   <?php
   //an option for showing authors names of the posts or pages
   $showauthorId = $this->get_field_id("showauthor");
    $showauthorName = $this->get_field_name("showauthor");
    ?><p><input id="<?php echo $showauthorId;?>" type="checkbox" name="<?php echo $showauthorName;?>" value="1" <?php checked( 1, $showauthor );?>>Show Author</p>
   <?php
   //an option for showing published dates of the posts or pages
   $showratingId = $this->get_field_id("showrating");
   $showratingName = $this->get_field_name("showrating");
    ?><p><input id="<?php echo $showratingId;?>" type="checkbox" name="<?php echo $showratingName;?>" value="1" <?php checked( 1, $showrating );?>>Show Rating</p>
   <?php
   //an option for showing modified dates of the posts or pages
   $showsalenumId = $this->get_field_id("salenum");
   $showsalenumName = $this->get_field_name("salenum");
    ?><p><input id="<?php echo $showsalenumId;?>" type="checkbox" name="<?php echo $showsalenumName;?>" value="1" <?php checked( 1, $showsalenum );?>>Show Total Sales</p>
   <?php
   //an option for showing comments count of the posts or pages
   $showreviewId = $this->get_field_id("review");
   $showreviewName = $this->get_field_name("review");
    ?><p><input id="<?php echo $showreviewId;?>" type="checkbox" name="<?php echo $showreviewName;?>" value="1" <?php checked( 1, $showreview );?>>Show number of Reviews</p>
   <?php
      $showactivepriceId = $this->get_field_id("activeprice");
   $showactivepriceName = $this->get_field_name("activeprice");
    ?><p><input id="<?php echo $showactivepriceId;?>" type="checkbox" name="<?php echo $showactivepriceName;?>" value="1" <?php checked( 1, $showactiveprice );?>>Show Active Price</p>
   <?php
   $showformerpriceId = $this->get_field_id("formerprice");
   $showformerpriceName = $this->get_field_name("formerprice");
    ?><p><input id="<?php echo $showformerpriceId;?>" type="checkbox" name="<?php echo $showformerpriceName;?>" value="1" <?php checked( 1, $showformerprice );?>>Show Former Price</p>
   <?php
      $showdescId = $this->get_field_id("showdesc");
   $showdescName = $this->get_field_name("showdesc");
    ?><p><input id="<?php echo $showdescId;?>" type="checkbox" name="<?php echo $showdescName;?>" value="1" <?php checked( 1, $showdesc );?>>Show Description</p>
    <?php
      $showmorebtnId = $this->get_field_id("showmorebtn");
   $showmorebtnName = $this->get_field_name("showmorebtn");
    ?><p><input id="<?php echo $showmorebtnId;?>" type="checkbox" name="<?php echo $showmorebtnName;?>" value="1" <?php checked( 1, $showmorebtn );?>>Show Read More Button</p>
    <?php
      $showcartbtnId = $this->get_field_id("showcartbtn");
   $showcartbtnName = $this->get_field_name("showcartbtn");
    ?><p><input id="<?php echo $showcartbtnId;?>" type="checkbox" name="<?php echo $showcartbtnName;?>" value="1" <?php checked( 1, $showcartbtn );?>>Show Add to cart Button</p>
    <?php
}
//sanitizing widget parameters
public function update($newInstance, $oldInstance) {
    $values = array();
    $values["title"] = sanitize_text_field($newInstance["title"]);
    $values["type"] = $newInstance["type"];
    $values["introsource"] = $newInstance["introsource"];
    $values["alltags"] = $newInstance["alltags"];
    $values["allcats"] = $newInstance["allcats"];
    $values["allauthors"] = $newInstance["allauthors"];
    $values["count"] = intval($newInstance["count"]);
    $values["limit"] = intval($newInstance["limit"]);
    $values["orderby"] = $newInstance["orderby"];
    $values["sort"] = $newInstance["sort"];
    $values["showcats"] = $newInstance["showcats"];
    $values["showauthor"] = $newInstance["showauthor"];
    $values["salenum"] = $newInstance["salenum"];
    $values["showrating"] = $newInstance["showrating"];
    $values["review"] = $newInstance["review"];
    $values["showdesc"] = $newInstance["showdesc"];
    $values["activeprice"] = $newInstance["activeprice"];
    $values["formerprice"] = $newInstance["formerprice"];
    $values["showmorebtn"] = $newInstance["showmorebtn"];
    $values["showcartbtn"] = $newInstance["showcartbtn"];
    $values["readmore"] = sanitize_text_field($newInstance["readmore"]);
    $values["addcart"] = sanitize_text_field($newInstance["addcart"]);
    return $values;
}
//adding CSS file and jquery accordion
function fsfwp_filterable_showcase_scripts() {
         wp_register_style( 'fsfwp-filterable-showcase', plugins_url( 'css/filterableshowcase.css', __FILE__ ) );
     wp_register_script( 'fsfwp-filterable-showcase', plugins_url( 'js/script.js', __FILE__ ),array('jquery'),'1.0',true );
     wp_register_script( 'fsfwp-filterable-showcase-script', plugins_url( 'js/fetchmore.js', __FILE__ ),array('jquery'),'1.0',true );
     wp_localize_script( 'fsfwp-filterable-showcase-script', 'fsfwp_ajax_url', array( 'ajax_url' => admin_url('admin-ajax.php'),'check_nonce'=>wp_create_nonce('fsfwp-nonce')) );

}


function fsfwproducts_ajax_callback(){
$params=array();
global $woocommerce;
check_ajax_referer( 'fsfwp-nonce', 'security' );
$params['offset']= isset($_POST['current_count'])?intval(sanitize_text_field($_POST['current_count'])):0;
$params['type']= isset($_POST['load_type'])?sanitize_text_field($_POST['load_type']):'';
$params['count']= isset($_POST['load_count'])?intval(sanitize_text_field($_POST['load_count'])):0;
$params['orderby']=isset($_POST['load_orderby'])?sanitize_text_field($_POST['load_orderby']):'';
$params['sort']= isset($_POST['load_sort'])?sanitize_text_field($_POST['load_sort']):'';
$allcats= isset($_POST['load_cats'])?explode(',',sanitize_text_field($_POST['load_cats'])):array();
$allauthors= isset($_POST['load_authors'])?explode(',',sanitize_text_field($_POST['load_authors'])):array();
$alltags= isset($_POST['load_tags'])?explode(',',sanitize_text_field($_POST['load_tags'])):array();
//$params['count']= $params['count']+$cur_count;
$attribs=explode(',',sanitize_text_field($_POST['load_attribs']));
$category=(!empty($attribs[0]))?intval($attribs[0]):0;
$author=(!empty($attribs[1]))?intval($attribs[1]):0;
$rating=(!empty($attribs[2]))?intval($attribs[2]):0;
$salenum=(!empty($attribs[3]))?intval($attribs[3]):0;
$review=(!empty($attribs[4]))?intval($attribs[4]):0;
$activeprice=(!empty($attribs[5]))?intval($attribs[5]):0;
$formerprice=(!empty($attribs[6]))?intval($attribs[6]):0;
$limit=(!empty($attribs[7]))?intval($attribs[7]):18;
$desc= (!empty($attribs[8]))?intval($attribs[8]):0;
$morebtn=(!empty($attribs[9]))?intval($attribs[9]):0;
$cartbtn=(!empty($attribs[10]))?intval($attribs[10]):0;
$readmore=(!empty($attribs[11]))?sanitize_text_field($attribs[11]):'';
$addcart=(!empty($attribs[12]))?sanitize_text_field($attribs[12]):'';
$params['introsource']=(!empty($attribs[13]))?intval($attribs[13]):2;
$posts_info= fsfwp_filterableshowcase_helper::fsfwp_filterable_showcase_get_article($allcats,$allauthors,$alltags,$params);
if(!empty($posts_info))
{
 foreach($posts_info as $k=>$c)
{
 $c_tmp=($category==1)?'<small class="fsfwpinfo">Category: '.$c->catlink.'</small><br>':'';
  $a_tmp=($author==1)?'<small class="fsfwpinfo">Author: '.$c->author_name.'</small><br>':'';
  $com_tmp=($review==1)?'<small class="fsfwpinfo">Reviews: '.$c->review.'</small><br>':'';
  $sale_tmp=($salenum==1)?'<small class="fsfwpinfo">Total Sales: '.$c->sales.'</small><br>':'';
  $rating_tmp=($rating==1)?wc_get_rating_html($c->rating,$c->ratingcount):'';
  $fprice_tmp=($formerprice==1 && $c->onsale)?'<div class="fsfwpformer">'.wc_price($c->formerprice).'</div><br>':'';
  $aprice_tmp=($activeprice==1)?'<div class="fsfwpactive">'.wc_price($c->activeprice).'</div><br>':'';
  $desc_tmp=($desc==1)?'<p>'.wp_trim_words($c->intro,$limit,'...').'</p>':'';
  $on_sale=($c->onsale)?'<div class="fsfwp_onsale">SALE</div>':'';
  $morebtn_tmp= ($morebtn==1)?'<a class="fsfwp_readmore" href="'.esc_url($c->link).'">'.esc_html($readmore).'</a>':'';
  $cartbtn_tmp= ($cartbtn==1)?'<a class="button fsfwp_cart add_to_cart_button ajax_add_to_cart" data-product_id="'.$c->ID.'" data-quantity="1" href="'.esc_url($c->cart).'" rel="nofollow">'.esc_html($addcart).'</a>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$com_tmp.$sale_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$com_tmp.$sale_tmp.'</div>':'';

  echo '<div class="'.$c->classname.'">';
    echo '<div class="fsfwp_content"><div class="fsfwp_container">'.$c->image.$on_sale.'<div class="fsfwp_overlay"><a class="fsfwp_imglink" href="'.esc_url($c->link).'"></a></div></div>'.$info_block.'<h4>'.$c->post_title.'</h4>'.$rating_tmp.$fprice_tmp.$aprice_tmp.$desc_tmp.'<div class="fsfwp_linksblock">'.$morebtn_tmp.$cartbtn_tmp.'</div>';
   echo '</div>';
 echo '</div>';


}

}
wp_die();
}
public function widget($args, $instance) {
     wp_enqueue_style( 'fsfwp-filterable-showcase');
     wp_enqueue_script( 'fsfwp-filterable-showcase' );
     wp_enqueue_script( 'fsfwp-filterable-showcase-script');
 global $woocommerce;
  $title=$instance["title"];
  $type=$instance["type"];
  $introsource = $instance["introsource"];
  $alltags=$instance["alltags"];
  $allcats=$instance["allcats"];
  $allauthors=$instance["allauthors"];
  $count=$instance["count"];
  $limit=$instance["limit"];
  $orderby=$instance["orderby"];
  $sort=$instance["sort"];
  $category=$instance["showcats"];
  $author=$instance["showauthor"];
  $salenum=$instance["salenum"];
  $review=$instance["review"];
  $activeprice=$instance["activeprice"];
  $formerprice=$instance["formerprice"];
  $rating=$instance["showrating"];
  $desc=$instance["showdesc"];
  $morebtn=$instance["showmorebtn"];
  $cartbtn=$instance["showcartbtn"];
  $readmore=$instance["readmore"];
  $addcart=$instance["addcart"];
  $source=array();
  $sourcename=array();
  if($type=='1')
  { $selectedtype='bytags';
    $source=$alltags;
    for($i=0;$i<count($source);$i++)
    { $sourcetmp[$i]= get_term($source[$i],'product_tag');
      $sourcename[$i]= $sourcetmp[$i]->name;
    }
  }
  else if($type=='2')
  {
  $selectedtype='bycats';
  $source=$allcats;
   for($i=0;$i<count($source);$i++)
    { $sourcetmp[$i]= get_term($source[$i],'product_cat');
    $sourcename[$i]= $sourcetmp[$i]->name;
    }
  }
  else if($type=='3')
  {
  $selectedtype='byauthors';
  $source=$allauthors;
     for($i=0;$i<count($source);$i++)
    { $sourcename[$i]=  get_the_author_meta('display_name',$source[$i]);

    }
  }
  $attribs=$category.','.$author.','.$rating.','.$salenum.','.$review.','.$activeprice.','.$formerprice.','.$limit.','.$desc.','.$morebtn.','.$cartbtn.','.$readmore.','.$addcart.','.$introsource;
  //getting posts by selected filters
  $params=array('type'=>$selectedtype,'count'=>$count,'orderby'=>$orderby,'sort'=>$sort,'introsource'=>$introsource,'offset'=>0);
  $posts_info= fsfwp_filterableshowcase_helper::fsfwp_filterable_showcase_get_article($allcats,$allauthors,$alltags,$params);

  //displaying the widget on frontend. It shows the title of widget if it is not empty
  echo $args['before_widget'];
  if(!empty($title))
  {	echo $args['before_title'];
    echo esc_html($title);
  	echo $args['after_title'];
  }
//showing the selected widgets
echo '<div id="filterable_showcase">';
 echo'<div id="fsfwpBtnContainer">';
  echo "<button class=\"btn showall active\" onclick=\"filterSelection('all')\"> Show all</button>";
  for($i=0;$i<count($source);$i++)
  echo "<button class=\"btn\" onclick=\"filterSelection('fsclass".$source[$i]."')\">".$sourcename[$i]."</button>";
 echo '</div>';
echo '<div class="fsfwprow">';
//display posts
echo '<div class="fsfwpitems">';
if(!empty($posts_info))
{
 foreach($posts_info as $c)
{

  $c_tmp=($category==1)?'<small class="fsfwpinfo">Category: '.$c->catlink.'</small><br>':'';
  $a_tmp=($author==1)?'<small class="fsfwpinfo">Author: '.$c->author_name.'</small><br>':'';
  $com_tmp=($review==1)?'<small class="fsfwpinfo">Reviews: '.$c->review.'</small><br>':'';
  $sale_tmp=($salenum==1)?'<small class="fsfwpinfo">Total Sales: '.$c->sales.'</small><br>':'';
  $rating_tmp=($rating==1)?wc_get_rating_html($c->rating,$c->ratingcount):'';
  $fprice_tmp=($formerprice==1 && $c->onsale)?'<div class="fsfwpformer">'.wc_price($c->formerprice).'</div><br>':'';
  $aprice_tmp=($activeprice==1)?'<div class="fsfwpactive">'.wc_price($c->activeprice).'</div><br>':'';
  $desc_tmp=($desc==1)?'<p>'.wp_trim_words($c->intro,$limit,'...').'</p>':'';
  $on_sale=($c->onsale)?'<div class="fsfwp_onsale">SALE</div>':'';
  $morebtn_tmp= ($morebtn==1)?'<a class="fsfwp_readmore" href="'.esc_url($c->link).'">'.esc_html($readmore).'</a>':'';
  $cartbtn_tmp= ($cartbtn==1)?'<a class="button fsfwp_cart add_to_cart_button ajax_add_to_cart" data-product_id="'.$c->ID.'" data-quantity="1" href="'.esc_url($c->cart).'" rel="nofollow">'.esc_html($addcart).'</a>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$com_tmp.$sale_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$com_tmp.$sale_tmp.'</div>':'';

  echo '<div class="'.$c->classname.'">';
    echo '<div class="fsfwp_content"><div class="fsfwp_container">'.$c->image.$on_sale.'<div class="fsfwp_overlay"><a class="fsfwp_imglink" href="'.esc_url($c->link).'"></a></div></div>'.$info_block.'<h4>'.$c->post_title.'</h4>'.$rating_tmp.$fprice_tmp.$aprice_tmp.$desc_tmp.'<div class="fsfwp_linksblock">'.$morebtn_tmp.$cartbtn_tmp.'</div>';
   echo '</div>';
 echo '</div>';

}

}
echo '</div>';
echo '<div id="load_container"><div id="fsfwp_loading" ><div id="fsfwp_loader"></div><div id="fsfwp_loadtext"> Loading ...</div></div><button id="fsfwp_load" class="" data-cats="'.implode(',',$allcats).'" data-authors="'.implode(',',$allauthors).'" data-tags="'.implode(',',$alltags).'" data-type="'.$params['type'].'" data-count="'.$params['count'].'" data-orderby="'.$params['orderby'].'" data-sort="'.$params['sort'].'" data-attribs="'.$attribs.'"> Load More</button></div>';
echo '</div>';
echo '</div>';

 echo $args['after_widget'];
}
}