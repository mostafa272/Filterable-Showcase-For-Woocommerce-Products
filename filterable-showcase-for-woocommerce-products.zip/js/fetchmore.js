jQuery(document).ready(function() {

    jQuery('#fsfwp_loading').hide();
    var att=jQuery('#fsfwp_load').data('attribs');
   
    jQuery('#fsfwp_load').on('click', function(e) {
    e.preventDefault();
    jQuery('#fsfwp_load').hide();
    jQuery('#fsfwp_loading').show();
    var count=jQuery('.fsfwpcolumn').length;
	jQuery.ajax({
		type: "POST",                 // use $_POST request to submit data
		url: fsfwp_ajax_url.ajax_url,      // URL to "wp-admin/admin-ajax.php"
		data: {
			action     : 'fsfwproducts', // wp_ajax_*, wp_ajax_nopriv_*
            security : fsfwp_ajax_url.check_nonce,
			current_count : count,
            load_type : jQuery('#fsfwp_load').data('type'),
            load_count : jQuery('#fsfwp_load').data('count'),
            load_orderby : jQuery('#fsfwp_load').data('orderby'),
            load_sort : jQuery('#fsfwp_load').data('sort'),
            load_attribs : jQuery('#fsfwp_load').data('attribs'),
            load_cats : jQuery('#fsfwp_load').data('cats'),
            load_authors : jQuery('#fsfwp_load').data('authors'),
            load_tags : jQuery('#fsfwp_load').data('tags')
		},
		success:function( data ) {
		  jQuery('.fsfwpitems').fadeOut(1).append( data ).fadeIn(500); //
          jQuery('#fsfwpBtnContainer .showall').trigger('click');
          jQuery('#fsfwp_loading').hide();
          jQuery('#fsfwp_load').show();
          var newcount=jQuery('.fsfwpcolumn').length;
          if(newcount-count == 0)jQuery('#fsfwp_load').fadeOut(500);
		},
		error: function(){
			console.log(errorThrown); // error
		}
	});

    });

});