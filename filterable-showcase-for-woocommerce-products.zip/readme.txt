=== Filterable Showcase For Woocommerce Products ===
Contributors: Mostafa Shahiri
Donate link: https://github.com/mostafa272/Filterable-Showcase-For-Woocommerce-Products
Tags: woocommerce , widget, products, tags, authors, categories, filter
Requires at least: 3.6.1
Tested up to: 4.9.x
Stable tag: 3.4.0
WC requires at least: 3.0.0

Filterable Showcase for Woocommerce Products is a simple widget that shows woocommerce products based on different filters

== Description ==

Filterable Showcase for Woocommerce Products is a simple widget that displays woocommerce products based on different filters.
It is a very useful and applicable plugin for your store or shopping websites that work with woocommerce. The Filterable Showcase
for Woocommerce Products enables you to show your products based on different filters and items. You can set the options of this
widget to filter products based on their tags, their categories or their authors. It gains AJAX method for loading more products to
improve the performance for your website. The Filterable Showcase for Woocommerce Products is very flexible plugin with customizable
settings ( See screenshot images ).


  **Some Features of The Filterable Showcase for Woocommerce Products:**

   1. Displaying products based on tags, categories and authors

   2. Gainig AJAX method for loading more products

   3. Easy to use

   4. Customizable settings

   5. Limiting the number of products

   6. Ordering products based on created date, modified date, reviews count, rating, total sales, price and random.

   7. Limiting the length of products descriptions

   8. Custom texts for readmore and add to cart links.

   9. Using a pretty style for displaying the items.



 **Settings of the Widget:**

  1. Title: A title for widget.Leave it empty if you don't like to show the title.

  2. Source Type: The plugin can filter products based on tags or categories or authors.

  3. Tags: Selected tags as the filters.

  4. Categories: Selected categories as the filters.

  5. Authors: Selected authors as the filters.

  6. Intro text source type: Select to display short description or main description of products

  7. Count: Number of products are shown in first review before loading more products.

  8. Limit Description Length: Number of words for truncating products descriptions.

  9. Order By: Ordering type.

  10. Order: Determine to order posts ascending or descending.

  11. Readmore Text: A text for readmore button.

  12. Add to cart Text: A text for add to cart button.


  Other options are used for showing or hiding products items.




== Installation ==

Upload this plugin to your blog, Activate it.

== Screenshots ==

1. Settings of the widget in admin panel.
2. Output in first review
3. Loading more products
4. Adding one more products


== Changelog ==

= 1.0 =
First release
